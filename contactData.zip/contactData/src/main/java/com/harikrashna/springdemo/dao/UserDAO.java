package com.harikrashna.springdemo.dao;

import java.util.List;

import com.harikrashna.springdemo.entity.User;

public interface UserDAO {
	
	public List<User> getUsers();

}
